export const quotes = [
  { text: "The stock market is a device for transferring money from the impatient to the patient.", author: "Warren Buffett", icon: "⛰️" },
  { text: "Risk comes from not knowing what you're doing.", author: "Warren Buffett", icon: "✈️" },
  { text: "The investor's chief problem — and even his worst enemy — is likely to be himself.", author: "Benjamin Graham", icon: "⛰️" },
  { text: "In the short run, the market is a voting machine, but in the long run, it is a weighing machine.", author: "Benjamin Graham", icon: "🏔️" },
  { text: "It's far better to buy a wonderful company at a fair price than a fair company at a wonderful price.", author: "Charlie Munger", icon: "✈️" },
  { text: "Invert, always invert. Turn a situation or problem upside down.", author: "Charlie Munger", icon: "⛰️" },
  { text: "He who lives by the crystal ball will eat shattered glass.", author: "Ray Dalio", icon: "🏔️" },
  { text: "The biggest mistake investors make is to believe that what happened in the recent past is likely to persist.", author: "Ray Dalio", icon: "✈️" },
  { text: "Know what you own, and know why you own it.", author: "Peter Lynch", icon: "⛰️" },
  { text: "Behind every stock is a company. Find out what it's doing.", author: "Peter Lynch", icon: "✈️" },
  { text: "The person that turns over the most rocks wins the game.", author: "Peter Lynch", icon: "🏔️" },
  { text: "Time in the market beats timing the market.", author: "Kenneth Fisher", icon: "⛰️" },
];
