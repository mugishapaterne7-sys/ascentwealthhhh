export const samplePortfolio = [
  { id: '1', name: 'Apple Inc.', type: 'Stock', ticker: 'AAPL', quantity: 10, purchasePrice: 150, currentPrice: 189, purchaseDate: '2023-01-15', notes: '' },
  { id: '2', name: 'Bitcoin', type: 'Crypto', ticker: 'BTC', quantity: 0.5, purchasePrice: 28000, currentPrice: 67000, purchaseDate: '2023-03-10', notes: '' },
  { id: '3', name: 'Vanguard S&P 500 ETF', type: 'ETF', ticker: 'VOO', quantity: 20, purchasePrice: 380, currentPrice: 450, purchaseDate: '2022-11-01', notes: '' },
  { id: '4', name: 'Ethereum', type: 'Crypto', ticker: 'ETH', quantity: 3, purchasePrice: 1600, currentPrice: 3500, purchaseDate: '2023-06-20', notes: '' },
  { id: '5', name: 'Cash Savings', type: 'Cash', ticker: '', quantity: 1, purchasePrice: 5000, currentPrice: 5000, purchaseDate: '2024-01-01', notes: 'Emergency fund' },
];

export const sampleGoals = [
  { id: '1', name: 'First $100K', targetAmount: 100000, targetDate: '2025-12-31', linkedToPortfolio: true, currentAmount: 0, notes: 'The hardest and most important milestone' },
  { id: '2', name: 'Financial Freedom Fund', targetAmount: 500000, targetDate: '2030-01-01', linkedToPortfolio: true, currentAmount: 0, notes: '' },
];
