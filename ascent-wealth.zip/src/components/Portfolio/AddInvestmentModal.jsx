import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

const assetTypes = ['Stock', 'Crypto', 'Real Estate', 'Cash', 'Bond', 'ETF', 'Other'];

export function AddInvestmentModal({ isOpen, onClose, onSubmit, editInvestment }) {
  const [form, setForm] = useState({
    name: '',
    type: 'Stock',
    ticker: '',
    quantity: '',
    purchasePrice: '',
    currentPrice: '',
    purchaseDate: new Date().toISOString().split('T')[0],
    notes: '',
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (editInvestment) {
      setForm({
        name: editInvestment.name || '',
        type: editInvestment.type || 'Stock',
        ticker: editInvestment.ticker || '',
        quantity: editInvestment.quantity || '',
        purchasePrice: editInvestment.purchasePrice || '',
        currentPrice: editInvestment.currentPrice || '',
        purchaseDate: editInvestment.purchaseDate || new Date().toISOString().split('T')[0],
        notes: editInvestment.notes || '',
      });
    } else {
      setForm({
        name: '',
        type: 'Stock',
        ticker: '',
        quantity: '',
        purchasePrice: '',
        currentPrice: '',
        purchaseDate: new Date().toISOString().split('T')[0],
        notes: '',
      });
    }
    setErrors({});
  }, [editInvestment, isOpen]);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Asset name is required';
    if (!form.quantity || Number(form.quantity) <= 0) newErrors.quantity = 'Valid quantity required';
    if (!form.purchasePrice || Number(form.purchasePrice) < 0) newErrors.purchasePrice = 'Valid purchase price required';
    if (!form.currentPrice || Number(form.currentPrice) < 0) newErrors.currentPrice = 'Valid current price required';
    if (!form.purchaseDate) newErrors.purchaseDate = 'Purchase date is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    onSubmit({
      ...form,
      quantity: Number(form.quantity),
      purchasePrice: Number(form.purchasePrice),
      currentPrice: Number(form.currentPrice),
    });
    onClose();
  };

  const inputClass = (field) => `
    w-full px-4 py-3 rounded-xl bg-white/5 border ${errors[field] ? 'border-red-500/50' : 'border-white/10'} 
    dark:text-white text-slate-900 placeholder-slate-500
    focus:outline-none focus:border-ascent-summit/50 focus:ring-1 focus:ring-ascent-summit/20
    transition-all
  `;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="relative w-full max-w-lg glass-card rounded-2xl p-6 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold dark:text-white text-slate-900">
                {editInvestment ? 'Edit Investment' : 'Add Investment'}
              </h2>
              <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/5 text-slate-400 hover:text-white transition-colors">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-1.5">Asset Name *</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g., Apple Inc."
                  className={inputClass('name')}
                />
                {errors.name && <p className="text-xs text-red-400 mt-1">{errors.name}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Asset Type *</label>
                  <select
                    value={form.type}
                    onChange={(e) => setForm({ ...form, type: e.target.value })}
                    className={inputClass('type')}
                  >
                    {assetTypes.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Ticker/Symbol</label>
                  <input
                    type="text"
                    value={form.ticker}
                    onChange={(e) => setForm({ ...form, ticker: e.target.value })}
                    placeholder="e.g., AAPL"
                    className={inputClass('ticker')}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Quantity *</label>
                  <input
                    type="number"
                    step="any"
                    value={form.quantity}
                    onChange={(e) => setForm({ ...form, quantity: e.target.value })}
                    placeholder="10"
                    className={inputClass('quantity')}
                  />
                  {errors.quantity && <p className="text-xs text-red-400 mt-1">{errors.quantity}</p>}
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Purchase Date *</label>
                  <input
                    type="date"
                    value={form.purchaseDate}
                    onChange={(e) => setForm({ ...form, purchaseDate: e.target.value })}
                    className={inputClass('purchaseDate')}
                  />
                  {errors.purchaseDate && <p className="text-xs text-red-400 mt-1">{errors.purchaseDate}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Purchase Price *</label>
                  <input
                    type="number"
                    step="any"
                    value={form.purchasePrice}
                    onChange={(e) => setForm({ ...form, purchasePrice: e.target.value })}
                    placeholder="150.00"
                    className={inputClass('purchasePrice')}
                  />
                  {errors.purchasePrice && <p className="text-xs text-red-400 mt-1">{errors.purchasePrice}</p>}
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Current Price *</label>
                  <input
                    type="number"
                    step="any"
                    value={form.currentPrice}
                    onChange={(e) => setForm({ ...form, currentPrice: e.target.value })}
                    placeholder="189.00"
                    className={inputClass('currentPrice')}
                  />
                  {errors.currentPrice && <p className="text-xs text-red-400 mt-1">{errors.currentPrice}</p>}
                </div>
              </div>

              <div>
                <label className="block text-sm text-slate-400 mb-1.5">Notes</label>
                <textarea
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="Optional notes..."
                  rows={3}
                  className={inputClass('notes')}
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 px-6 rounded-xl bg-gradient-to-r from-ascent-aurora to-ascent-summit text-white font-medium
                  hover:shadow-[0_0_30px_rgba(99,102,241,0.3)] transition-shadow"
              >
                {editInvestment ? 'Update Investment' : 'Add to Portfolio'}
              </button>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
