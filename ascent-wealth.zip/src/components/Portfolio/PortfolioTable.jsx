import React from 'react';
import { motion } from 'framer-motion';
import { Pencil, Trash2, TrendingUp, TrendingDown } from 'lucide-react';
import { GlassCard } from '../UI/GlassCard';
import { AnimatedNumber } from '../UI/AnimatedNumber';

export function PortfolioTable({ investments, onEdit, onDelete, filter }) {
  const filtered = filter === 'All' 
    ? investments 
    : investments.filter(inv => inv.type === filter);

  return (
    <div className="space-y-3">
      {filtered.map((inv, index) => {
        const isGain = inv.gain >= 0;
        return (
          <motion.div
            key={inv.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05, duration: 0.3 }}
          >
            <GlassCard hover className="flex items-center gap-4 py-4 px-5">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-ascent-aurora/30 to-ascent-summit/30 flex items-center justify-center flex-shrink-0">
                <span className="text-xs font-bold text-white">{inv.ticker || inv.name.slice(0, 2).toUpperCase()}</span>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h4 className="font-medium dark:text-white text-slate-900 truncate">{inv.name}</h4>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-white/5 text-slate-400">{inv.type}</span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">{inv.quantity} units @ ${inv.purchasePrice}</p>
              </div>

              <div className="hidden md:block text-right">
                <p className="text-sm text-slate-400">Current</p>
                <p className="text-sm font-medium dark:text-white text-slate-900">${inv.currentPrice}</p>
              </div>

              <div className="hidden lg:block text-right min-w-[100px]">
                <p className="text-sm text-slate-400">Value</p>
                <p className="text-sm font-medium dark:text-white text-slate-900">
                  <AnimatedNumber value={inv.totalValue} prefix="$" decimals={0} />
                </p>
              </div>

              <div className="text-right min-w-[100px]">
                <div className={`flex items-center justify-end gap-1 text-sm font-medium ${isGain ? 'text-emerald-400' : 'text-red-400'}`}>
                  {isGain ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                  <AnimatedNumber value={inv.gain} prefix={isGain ? '+$' : '-$'} decimals={0} />
                </div>
                <p className={`text-xs ${isGain ? 'text-emerald-400/70' : 'text-red-400/70'}`}>
                  {isGain ? '+' : ''}{inv.gainPercent.toFixed(1)}%
                </p>
              </div>

              <div className="flex items-center gap-1 flex-shrink-0">
                <button
                  onClick={() => onEdit(inv)}
                  className="p-2 rounded-lg hover:bg-white/5 text-slate-400 hover:text-white transition-colors"
                >
                  <Pencil size={14} />
                </button>
                <button
                  onClick={() => onDelete(inv.id)}
                  className="p-2 rounded-lg hover:bg-red-500/10 text-slate-400 hover:text-red-400 transition-colors"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </GlassCard>
          </motion.div>
        );
      })}

      {filtered.length === 0 && (
        <div className="text-center py-12 text-slate-500">
          No investments found in this category.
        </div>
      )}
    </div>
  );
}
