import React from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from '../UI/GlassCard';
import { AnimatedNumber } from '../UI/AnimatedNumber';

export function AltitudeBar({ totalValue, goals }) {
  // Use the highest goal as summit target, or default to 500k
  const summitGoal = goals.length > 0 
    ? Math.max(...goals.map(g => g.targetAmount))
    : 500000;

  const progress = Math.min(100, (totalValue / summitGoal) * 100);

  return (
    <GlassCard className="relative">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium dark:text-white text-slate-900">Altitude Meter</h3>
        <span className="text-sm text-slate-400">
          Summit Goal: <AnimatedNumber value={summitGoal} prefix="$" decimals={0} />
        </span>
      </div>

      <div className="relative h-12 bg-white/5 rounded-xl overflow-hidden border border-white/5">
        {/* Runway markings */}
        <div className="absolute inset-0 flex items-center justify-between px-4">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="w-px h-4 bg-white/10" />
          ))}
        </div>

        {/* Progress fill */}
        <motion.div
          className="absolute inset-y-0 left-0 rounded-xl"
          style={{
            width: `${progress}%`,
            background: 'linear-gradient(90deg, #6366f1 0%, #0ea5e9 50%, #10b981 100%)',
          }}
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 1.5, type: 'spring', stiffness: 50 }}
        />

        {/* Airplane indicator */}
        <motion.div
          className="absolute top-1/2 -translate-y-1/2 text-xl"
          style={{ left: `${progress}%` }}
          initial={{ left: 0 }}
          animate={{ left: `${progress}%` }}
          transition={{ duration: 1.5, type: 'spring', stiffness: 50 }}
        >
          <span className="relative -translate-x-1/2 inline-block">✈️</span>
        </motion.div>
      </div>

      <div className="flex justify-between mt-3 text-xs text-slate-400">
        <span>Ground Level $0</span>
        <span className="text-ascent-summit font-medium">
          You are {progress.toFixed(1)}% of the way to your summit
        </span>
        <span>Summit ${summitGoal.toLocaleString()}</span>
      </div>
    </GlassCard>
  );
}
