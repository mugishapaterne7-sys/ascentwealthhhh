import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Plane } from 'lucide-react';
import { GlassCard } from '../UI/GlassCard';
import { AnimatedNumber } from '../UI/AnimatedNumber';
import { Badge } from '../UI/Badge';
import { AreaChart, Area, ResponsiveContainer, Tooltip } from 'recharts';

const taglines = [
  "You're above the clouds.",
  "Keep climbing.",
  "The summit is closer than you think.",
];

export function NetWorthHero({ totalValue, totalGain, totalGainPercent, snapshots }) {
  const [taglineIndex, setTaglineIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTaglineIndex((prev) => (prev + 1) % taglines.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const sparkData = snapshots.slice(-30).map((s, i) => ({
    day: i,
    value: s.totalValue,
  }));

  return (
    <GlassCard glow className="relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-ascent-aurora/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />

      <div className="relative z-10">
        <div className="flex items-start justify-between mb-2">
          <div>
            <p className="text-sm text-slate-400 mb-1 uppercase tracking-wider">Total Net Worth</p>
            <h2 className="font-serif-display text-5xl md:text-6xl dark:text-white text-slate-900">
              <AnimatedNumber 
                value={totalValue} 
                prefix="$" 
                decimals={0} 
              />
            </h2>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-ascent-summit/10 border border-ascent-summit/20">
            <Plane size={14} className="text-ascent-summit" />
            <span className="text-sm font-medium text-ascent-summit">
              ALTITUDE: {totalValue.toLocaleString()} ft
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3 mb-6">
          <Badge value={totalGainPercent} prefix="" />
          <span className="text-sm text-slate-400">
            <AnimatedNumber value={totalGain} prefix="$" decimals={0} /> this month
          </span>
        </div>

        <div className="flex items-center justify-between">
          <motion.p
            key={taglineIndex}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="text-lg italic dark:text-slate-300 text-slate-600 font-serif-display"
          >
            "{taglines[taglineIndex]}"
          </motion.p>

          {/* Mini sparkline */}
          <div className="w-48 h-16">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sparkData}>
                <defs>
                  <linearGradient id="sparkGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="#6366f1"
                  strokeWidth={2}
                  fill="url(#sparkGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </GlassCard>
  );
}
