import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GlassCard } from '../UI/GlassCard';
import { quotes } from '../../data/quotes';
import { Mountain } from 'lucide-react';

export function QuoteCard() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % quotes.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const quote = quotes[index];

  return (
    <GlassCard className="relative overflow-hidden">
      <div className="absolute -right-4 -bottom-4 opacity-[0.03]">
        <Mountain size={120} />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
          className="relative z-10"
        >
          <p className="text-xl md:text-2xl italic font-serif-display dark:text-white text-slate-800 leading-relaxed mb-4">
            "{quote.text}"
          </p>
          <div className="flex items-center gap-2">
            <span className="text-2xl">{quote.icon}</span>
            <span className="text-sm text-slate-400 font-medium">{quote.author}</span>
          </div>
        </motion.div>
      </AnimatePresence>
    </GlassCard>
  );
}
