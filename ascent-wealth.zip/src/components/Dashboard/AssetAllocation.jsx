import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';
import { GlassCard } from '../UI/GlassCard';

const COLORS = {
  Stock: '#6366f1',
  Crypto: '#0ea5e9',
  ETF: '#10b981',
  Cash: '#f59e0b',
  'Real Estate': '#ec4899',
  Bond: '#8b5cf6',
  Other: '#64748b',
};

export function AssetAllocation({ allocationByType, totalValue }) {
  const data = Object.entries(allocationByType)
    .filter(([_, value]) => value > 0)
    .map(([name, value]) => ({
      name,
      value: Math.round(value),
      percent: totalValue > 0 ? ((value / totalValue) * 100).toFixed(1) : 0,
    }));

  return (
    <GlassCard className="h-full">
      <h3 className="text-lg font-medium mb-4 dark:text-white text-slate-900">Asset Allocation</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={90}
              paddingAngle={4}
              dataKey="value"
              stroke="none"
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={COLORS[entry.name] || COLORS.Other}
                />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="flex flex-wrap gap-3 mt-4 justify-center">
        {data.map((item) => (
          <div key={item.name} className="flex items-center gap-2">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: COLORS[item.name] || COLORS.Other }}
            />
            <span className="text-xs text-slate-400">
              {item.name} ({item.percent}%)
            </span>
          </div>
        ))}
      </div>
    </GlassCard>
  );
}
