import React, { useMemo } from 'react';

export function MountainBackground({ altitude = 0 }) {
  const stars = useMemo(() => {
    return Array.from({ length: 80 }, (_, i) => ({
      id: i,
      cx: Math.random() * 100,
      cy: Math.random() * 60,
      r: Math.random() * 0.8 + 0.2,
      opacity: Math.random() * 0.6 + 0.2,
    }));
  }, []);

  const mountainShift = Math.min(altitude * 0.3, 20);

  return (
    <div className="mountain-bg">
      <svg
        className="w-full h-full"
        viewBox={`0 0 1440 900`}
        preserveAspectRatio="xMidYMid slice"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="skyGrad" x1="0" y1="1" x2="0" y2="0">
            <stop offset="0%" stopColor="#030712" />
            <stop offset="40%" stopColor="#0c1445" />
            <stop offset="70%" stopColor="#1e1b4b" />
            <stop offset="100%" stopColor="#0f172a" />
          </linearGradient>
          <linearGradient id="skyGradLight" x1="0" y1="1" x2="0" y2="0">
            <stop offset="0%" stopColor="#f0f4ff" />
            <stop offset="50%" stopColor="#e0e7ff" />
            <stop offset="100%" stopColor="#c7d2fe" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Sky */}
        <rect width="1440" height="900" fill="url(#skyGrad)" className="dark:block hidden" />
        <rect width="1440" height="900" fill="url(#skyGradLight)" className="dark:hidden block" />

        {/* Stars */}
        <g className="dark:block hidden">
          {stars.map((star) => (
            <circle
              key={star.id}
              cx={`${star.cx}%`}
              cy={`${star.cy}%`}
              r={star.r}
              fill="white"
              opacity={star.opacity}
            />
          ))}
        </g>

        {/* Aurora effect */}
        <ellipse
          cx="720"
          cy="200"
          rx="600"
          ry="150"
          fill="rgba(99,102,241,0.08)"
          filter="url(#glow)"
          className="dark:block hidden"
        />
        <ellipse
          cx="720"
          cy="250"
          rx="500"
          ry="120"
          fill="rgba(14,165,233,0.06)"
          filter="url(#glow)"
          className="dark:block hidden"
        />

        {/* Back mountain range */}
        <path
          d={`M0,900 L0,${500 - mountainShift * 0.3} Q180,${420 - mountainShift * 0.3} 360,${480 - mountainShift * 0.3} T720,${400 - mountainShift * 0.3} T1080,${450 - mountainShift * 0.3} T1440,${380 - mountainShift * 0.3} L1440,900 Z`}
          fill="#1e1b4b"
          className="dark:fill-[#1e1b4b] fill-[#c7d2fe]"
          opacity="0.6"
        />

        {/* Mid mountain range */}
        <path
          d={`M0,900 L0,${600 - mountainShift * 0.6} Q200,${520 - mountainShift * 0.6} 400,${580 - mountainShift * 0.6} T800,${500 - mountainShift * 0.6} T1200,${560 - mountainShift * 0.6} T1440,${480 - mountainShift * 0.6} L1440,900 Z`}
          fill="#312e81"
          className="dark:fill-[#312e81] fill-[#a5b4fc]"
          opacity="0.7"
        />

        {/* Front mountain range */}
        <path
          d={`M0,900 L0,${700 - mountainShift} Q240,${620 - mountainShift} 480,${680 - mountainShift} T960,${600 - mountainShift} T1440,${650 - mountainShift} L1440,900 Z`}
          fill="#0f0f1a"
          className="dark:fill-[#0f0f1a] fill-[#818cf8]"
        />

        {/* Clouds */}
        <g opacity="0.03" className="dark:opacity-[0.03] opacity-[0.08]">
          <ellipse cx="200" cy="300" rx="120" ry="30" fill="white" className="animate-drift" />
          <ellipse cx="600" cy="200" rx="150" ry="35" fill="white" className="animate-drift" style={{ animationDelay: '-20s' }} />
          <ellipse cx="1000" cy="350" rx="100" ry="25" fill="white" className="animate-drift" style={{ animationDelay: '-40s' }} />
          <ellipse cx="1300" cy="250" rx="130" ry="28" fill="white" className="animate-drift" style={{ animationDelay: '-10s' }} />
        </g>

        {/* Altitude airplane indicator */}
        <g
          transform={`translate(1380, ${800 - altitude * 7})`}
          className="dark:block hidden"
        >
          <text
            x="0"
            y="0"
            fontSize="20"
            fill="#0ea5e9"
            filter="url(#glow)"
            textAnchor="middle"
          >
            ✈
          </text>
          <circle cx="0" cy="-2" r="15" fill="none" stroke="#0ea5e9" strokeWidth="0.5" opacity="0.3" />
        </g>
      </svg>
    </div>
  );
}
