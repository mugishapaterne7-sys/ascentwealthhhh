import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { LayoutDashboard, Briefcase, Target, Mountain } from 'lucide-react';
import { motion } from 'framer-motion';

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/portfolio', label: 'Portfolio', icon: Briefcase },
  { path: '/goals', label: 'Goals', icon: Target },
];

const phrases = [
  "Every dollar is a soldier.",
  "Compound interest never sleeps.",
  "Your future self is watching.",
];

export function Sidebar() {
  const location = useLocation();
  const [phraseIndex, setPhraseIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setPhraseIndex((prev) => (prev + 1) % phrases.length);
    }, 86400000);
    return () => clearInterval(interval);
  }, []);

  return (
    <aside className="fixed left-0 top-0 h-full w-64 z-50 glass-card border-r border-white/5 flex flex-col hidden md:flex">
      <div className="p-6 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-ascent-aurora to-ascent-summit flex items-center justify-center">
            <Mountain size={20} className="text-white" />
          </div>
          <div>
            <h1 className="font-serif-display text-xl tracking-wider text-white">
              ASCENT
            </h1>
            <p className="text-[10px] tracking-[0.2em] text-ascent-summit uppercase font-medium">
              Wealth
            </p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => `
                flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 relative
                ${isActive
                  ? 'bg-gradient-to-r from-ascent-aurora/20 to-transparent border-l-2 border-ascent-summit text-white shadow-[0_0_20px_rgba(99,102,241,0.15)]'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
                }
              `}
            >
              <Icon size={18} className={isActive ? 'text-ascent-summit' : ''} />
              {item.label}
            </NavLink>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/5">
        <motion.p
          key={phraseIndex}
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-xs text-slate-500 italic text-center"
        >
          "{phrases[phraseIndex]}"
        </motion.p>
      </div>
    </aside>
  );
}
