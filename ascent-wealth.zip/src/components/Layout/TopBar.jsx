import React, { useState, useEffect } from 'react';
import { Sun, Moon, User } from 'lucide-react';

export function TopBar() {
  const [isDark, setIsDark] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('ascent_theme');
    if (stored) {
      setIsDark(stored === 'dark');
      document.documentElement.classList.toggle('dark', stored === 'dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = () => {
    const newDark = !isDark;
    setIsDark(newDark);
    document.documentElement.classList.toggle('dark', newDark);
    localStorage.setItem('ascent_theme', newDark ? 'dark' : 'light');
  };

  const greetings = ['Good morning, climber.', 'The summit awaits.', 'Keep ascending.', 'Above the clouds.'];
  const greeting = greetings[new Date().getHours() % greetings.length];

  return (
    <header className="h-16 flex items-center justify-between px-8 glass-card border-b border-white/5 z-40">
      <div>
        <p className="text-sm text-slate-400">{greeting}</p>
      </div>
      <div className="flex items-center gap-4">
        <button
          onClick={toggleTheme}
          className="p-2 rounded-xl hover:bg-white/5 transition-colors text-slate-400 hover:text-white"
        >
          {isDark ? <Sun size={18} /> : <Moon size={18} />}
        </button>
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-ascent-aurora to-ascent-summit flex items-center justify-center">
          <User size={14} className="text-white" />
        </div>
      </div>
    </header>
  );
}
