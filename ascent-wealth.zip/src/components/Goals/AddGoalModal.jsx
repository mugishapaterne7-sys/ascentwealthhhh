import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

export function AddGoalModal({ isOpen, onClose, onSubmit, editGoal }) {
  const [form, setForm] = useState({
    name: '',
    targetAmount: '',
    targetDate: '',
    linkedToPortfolio: true,
    currentAmount: '',
    notes: '',
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (editGoal) {
      setForm({
        name: editGoal.name || '',
        targetAmount: editGoal.targetAmount || '',
        targetDate: editGoal.targetDate || '',
        linkedToPortfolio: editGoal.linkedToPortfolio ?? true,
        currentAmount: editGoal.currentAmount || '',
        notes: editGoal.notes || '',
      });
    } else {
      setForm({
        name: '',
        targetAmount: '',
        targetDate: '',
        linkedToPortfolio: true,
        currentAmount: '',
        notes: '',
      });
    }
    setErrors({});
  }, [editGoal, isOpen]);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Goal name is required';
    if (!form.targetAmount || Number(form.targetAmount) <= 0) newErrors.targetAmount = 'Valid target amount required';
    if (!form.targetDate) newErrors.targetDate = 'Target date is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    onSubmit({
      ...form,
      targetAmount: Number(form.targetAmount),
      currentAmount: form.currentAmount ? Number(form.currentAmount) : 0,
    });
    onClose();
  };

  const inputClass = (field) => `
    w-full px-4 py-3 rounded-xl bg-white/5 border ${errors[field] ? 'border-red-500/50' : 'border-white/10'} 
    dark:text-white text-slate-900 placeholder-slate-500
    focus:outline-none focus:border-ascent-summit/50 focus:ring-1 focus:ring-ascent-summit/20
    transition-all
  `;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
        >
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="relative w-full max-w-lg glass-card rounded-2xl p-6 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold dark:text-white text-slate-900">
                {editGoal ? 'Edit Goal' : 'Set New Goal'}
              </h2>
              <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/5 text-slate-400 hover:text-white transition-colors">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-1.5">Goal Name *</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g., First $100K"
                  className={inputClass('name')}
                />
                {errors.name && <p className="text-xs text-red-400 mt-1">{errors.name}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Target Amount ($) *</label>
                  <input
                    type="number"
                    step="any"
                    value={form.targetAmount}
                    onChange={(e) => setForm({ ...form, targetAmount: e.target.value })}
                    placeholder="100000"
                    className={inputClass('targetAmount')}
                  />
                  {errors.targetAmount && <p className="text-xs text-red-400 mt-1">{errors.targetAmount}</p>}
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Target Date *</label>
                  <input
                    type="date"
                    value={form.targetDate}
                    onChange={(e) => setForm({ ...form, targetDate: e.target.value })}
                    className={inputClass('targetDate')}
                  />
                  {errors.targetDate && <p className="text-xs text-red-400 mt-1">{errors.targetDate}</p>}
                </div>
              </div>

              <div className="flex items-center gap-3 py-2">
                <input
                  type="checkbox"
                  id="linkPortfolio"
                  checked={form.linkedToPortfolio}
                  onChange={(e) => setForm({ ...form, linkedToPortfolio: e.target.checked })}
                  className="w-4 h-4 rounded border-white/20 bg-white/5 text-ascent-summit focus:ring-ascent-summit/20"
                />
                <label htmlFor="linkPortfolio" className="text-sm text-slate-400">
                  Link progress to portfolio net worth
                </label>
              </div>

              {!form.linkedToPortfolio && (
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Current Amount ($)</label>
                  <input
                    type="number"
                    step="any"
                    value={form.currentAmount}
                    onChange={(e) => setForm({ ...form, currentAmount: e.target.value })}
                    placeholder="0"
                    className={inputClass('currentAmount')}
                  />
                </div>
              )}

              <div>
                <label className="block text-sm text-slate-400 mb-1.5">Notes</label>
                <textarea
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="Optional notes..."
                  rows={3}
                  className={inputClass('notes')}
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 px-6 rounded-xl bg-gradient-to-r from-ascent-aurora to-ascent-summit text-white font-medium
                  hover:shadow-[0_0_30px_rgba(99,102,241,0.3)] transition-shadow"
              >
                {editGoal ? 'Update Goal' : 'Set Goal'}
              </button>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
