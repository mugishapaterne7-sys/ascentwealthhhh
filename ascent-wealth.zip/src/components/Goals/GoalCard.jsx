import React from 'react';
import { motion } from 'framer-motion';
import { Pencil, Trash2, Mountain, CheckCircle2 } from 'lucide-react';
import { GlassCard } from '../UI/GlassCard';
import { AnimatedNumber } from '../UI/AnimatedNumber';

export function GoalCard({ goal, onEdit, onDelete }) {
  return (
    <GlassCard hover className="relative overflow-hidden">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${goal.isAchieved ? 'bg-emerald-500/20' : 'bg-ascent-aurora/20'}`}>
            {goal.isAchieved ? (
              <CheckCircle2 size={20} className="text-emerald-400" />
            ) : (
              <Mountain size={20} className="text-ascent-summit" />
            )}
          </div>
          <div>
            <h3 className="font-medium dark:text-white text-slate-900">{goal.name}</h3>
            <p className="text-xs text-slate-500">
              Target: <AnimatedNumber value={goal.targetAmount} prefix="$" decimals={0} /> by {goal.targetDate}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => onEdit(goal)}
            className="p-2 rounded-lg hover:bg-white/5 text-slate-400 hover:text-white transition-colors"
          >
            <Pencil size={14} />
          </button>
          <button
            onClick={() => onDelete(goal.id)}
            className="p-2 rounded-lg hover:bg-red-500/10 text-slate-400 hover:text-red-400 transition-colors"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      {/* Mountain progress visual */}
      <div className="relative h-32 mb-4">
        <svg viewBox="0 0 200 100" className="w-full h-full" preserveAspectRatio="none">
          {/* Mountain outline */}
          <path
            d="M0,100 L50,40 L100,10 L150,40 L200,100 Z"
            fill="none"
            stroke="rgba(255,255,255,0.1)"
            strokeWidth="1"
          />
          {/* Filled portion */}
          <defs>
            <clipPath id={`mountain-clip-${goal.id}`}>
              <path d="M0,100 L50,40 L100,10 L150,40 L200,100 Z" />
            </clipPath>
          </defs>
          <rect
            x="0"
            y={100 - (goal.progress / 100) * 100}
            width="200"
            height="100"
            fill="url(#mountainGrad)"
            clipPath={`url(#mountain-clip-${goal.id})`}
          />
          <linearGradient id="mountainGrad" x1="0" y1="1" x2="0" y2="0">
            <stop offset="0%" stopColor="#6366f1" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#0ea5e9" stopOpacity="0.6" />
          </linearGradient>

          {/* Peak flag */}
          {goal.isAchieved && (
            <motion.g
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 200 }}
            >
              <line x1="100" y1="10" x2="100" y2="-5" stroke="#f59e0b" strokeWidth="2" />
              <polygon points="100,-5 115,2 100,9" fill="#f59e0b" />
            </motion.g>
          )}
        </svg>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold dark:text-white text-slate-900">
              {goal.progress.toFixed(1)}%
            </span>
            <span className="text-sm text-slate-500">
              <AnimatedNumber value={goal.currentAmount} prefix="$" decimals={0} /> / <AnimatedNumber value={goal.targetAmount} prefix="$" decimals={0} />
            </span>
          </div>
        </div>
        <div>
          {goal.isAchieved ? (
            <span className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium flex items-center gap-1">
              <Mountain size={12} /> ACHIEVED 🏔️
            </span>
          ) : (
            <span className="text-xs text-slate-500">
              {goal.daysRemaining > 0 ? `${goal.daysRemaining} days remaining` : 'Overdue'}
            </span>
          )}
        </div>
      </div>

      {goal.notes && (
        <p className="text-xs text-slate-500 mt-3 italic">{goal.notes}</p>
      )}
    </GlassCard>
  );
}
