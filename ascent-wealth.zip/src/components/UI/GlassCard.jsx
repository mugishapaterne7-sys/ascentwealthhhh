import React from 'react';
import { motion } from 'framer-motion';

export function GlassCard({ children, className = '', hover = true, glow = false, delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.5, delay, type: 'spring', stiffness: 100 }}
      className={`
        glass-card rounded-2xl p-6
        ${hover ? 'glass-card-hover transition-all duration-300' : ''}
        ${glow ? 'gradient-border' : ''}
        ${className}
      `}
    >
      {children}
    </motion.div>
  );
}
