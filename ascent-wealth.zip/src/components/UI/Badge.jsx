import React from 'react';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

export function Badge({ value, prefix = '', suffix = '%', className = '' }) {
  const num = Number(value);
  const isPositive = num > 0;
  const isNeutral = num === 0;

  const colors = isPositive
    ? 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20'
    : isNeutral
    ? 'text-slate-400 bg-slate-400/10 border-slate-400/20'
    : 'text-red-400 bg-red-400/10 border-red-400/20';

  const Icon = isPositive ? TrendingUp : isNeutral ? Minus : TrendingDown;

  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${colors} ${className}`}>
      <Icon size={12} />
      {prefix}{isPositive ? '+' : ''}{num.toFixed(2)}{suffix}
    </span>
  );
}
