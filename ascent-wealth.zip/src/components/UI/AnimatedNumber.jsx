import React, { useEffect, useState, useRef } from 'react';
import { useSpring, useTransform, motion, useMotionValue } from 'framer-motion';

export function AnimatedNumber({ value, prefix = '', suffix = '', decimals = 0, className = '' }) {
  const [displayValue, setDisplayValue] = useState(0);
  const motionValue = useMotionValue(0);
  const springValue = useSpring(motionValue, { stiffness: 100, damping: 30 });
  const transformValue = useTransform(springValue, (v) => v.toFixed(decimals));

  useEffect(() => {
    motionValue.set(value);
  }, [value, motionValue]);

  useEffect(() => {
    const unsubscribe = springValue.on('change', (v) => {
      setDisplayValue(v);
    });
    return unsubscribe;
  }, [springValue]);

  const formatted = Number(displayValue).toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });

  return (
    <span className={className}>
      {prefix}{formatted}{suffix}
    </span>
  );
}
