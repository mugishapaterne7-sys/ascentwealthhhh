import { useState, useEffect, useCallback, useMemo } from 'react';
import { sampleGoals } from '../data/sampleData';

const STORAGE_KEY = 'ascent_goals';

const generateId = () => Math.random().toString(36).substring(2, 9);

const getInitialGoals = () => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) return JSON.parse(stored);
  return sampleGoals;
};

export function useGoals(portfolioValue = 0) {
  const [goals, setGoals] = useState(getInitialGoals);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(goals));
  }, [goals]);

  const addGoal = useCallback((goal) => {
    const newGoal = { ...goal, id: generateId() };
    setGoals(prev => [...prev, newGoal]);
  }, []);

  const updateGoal = useCallback((id, updates) => {
    setGoals(prev => prev.map(g => g.id === id ? { ...g, ...updates } : g));
  }, []);

  const deleteGoal = useCallback((id) => {
    setGoals(prev => prev.filter(g => g.id !== id));
  }, []);

  const computedGoals = useMemo(() => {
    return goals.map(goal => {
      const currentAmount = goal.linkedToPortfolio ? portfolioValue : (goal.currentAmount || 0);
      const progress = goal.targetAmount > 0 ? Math.min(100, (currentAmount / goal.targetAmount) * 100) : 0;
      const daysRemaining = Math.max(0, Math.ceil((new Date(goal.targetDate) - new Date()) / (1000 * 60 * 60 * 24)));
      const isAchieved = currentAmount >= goal.targetAmount;
      return { ...goal, currentAmount, progress, daysRemaining, isAchieved };
    });
  }, [goals, portfolioValue]);

  return {
    goals: computedGoals,
    addGoal,
    updateGoal,
    deleteGoal,
  };
}
