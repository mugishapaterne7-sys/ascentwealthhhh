import { useState, useEffect, useCallback, useMemo } from 'react';
import { samplePortfolio } from '../data/sampleData';

const STORAGE_KEY = 'ascent_portfolio';
const SNAPSHOTS_KEY = 'ascent_snapshots';

const generateId = () => Math.random().toString(36).substring(2, 9);

const getInitialPortfolio = () => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) return JSON.parse(stored);
  return samplePortfolio;
};

const getInitialSnapshots = () => {
  const stored = localStorage.getItem(SNAPSHOTS_KEY);
  if (stored) return JSON.parse(stored);
  // Generate 30 days of sample snapshots
  const snapshots = [];
  const baseValue = 85000;
  for (let i = 29; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const variation = (Math.random() - 0.4) * 0.02;
    const value = baseValue * (1 + (29 - i) * 0.005 + variation);
    snapshots.push({
      date: date.toISOString().split('T')[0],
      totalValue: Math.round(value),
    });
  }
  return snapshots;
};

export function usePortfolio() {
  const [investments, setInvestments] = useState(getInitialPortfolio);
  const [snapshots, setSnapshots] = useState(getInitialSnapshots);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(investments));
  }, [investments]);

  useEffect(() => {
    localStorage.setItem(SNAPSHOTS_KEY, JSON.stringify(snapshots));
  }, [snapshots]);

  // Auto-snapshot daily
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const lastSnapshot = snapshots[snapshots.length - 1];
    if (!lastSnapshot || lastSnapshot.date !== today) {
      const totalValue = investments.reduce((sum, inv) => sum + inv.quantity * inv.currentPrice, 0);
      setSnapshots(prev => [...prev.slice(-89), { date: today, totalValue: Math.round(totalValue) }]);
    }
  }, [investments, snapshots]);

  const addInvestment = useCallback((investment) => {
    const newInv = { ...investment, id: generateId() };
    setInvestments(prev => [...prev, newInv]);
  }, []);

  const updateInvestment = useCallback((id, updates) => {
    setInvestments(prev => prev.map(inv => inv.id === id ? { ...inv, ...updates } : inv));
  }, []);

  const deleteInvestment = useCallback((id) => {
    setInvestments(prev => prev.filter(inv => inv.id !== id));
  }, []);

  const computed = useMemo(() => {
    const enriched = investments.map(inv => {
      const totalValue = inv.quantity * inv.currentPrice;
      const totalCost = inv.quantity * inv.purchasePrice;
      const gain = totalValue - totalCost;
      const gainPercent = totalCost > 0 ? (gain / totalCost) * 100 : 0;
      return { ...inv, totalValue, totalCost, gain, gainPercent };
    });

    const totalValue = enriched.reduce((sum, inv) => sum + inv.totalValue, 0);
    const totalCost = enriched.reduce((sum, inv) => sum + inv.totalCost, 0);
    const totalGain = totalValue - totalCost;
    const totalGainPercent = totalCost > 0 ? (totalGain / totalCost) * 100 : 0;

    const allocationByType = enriched.reduce((acc, inv) => {
      acc[inv.type] = (acc[inv.type] || 0) + inv.totalValue;
      return acc;
    }, {});

    const bestPerformer = enriched.length > 0
      ? enriched.reduce((best, inv) => inv.gainPercent > best.gainPercent ? inv : best, enriched[0])
      : null;

    const firstDate = enriched.length > 0
      ? enriched.reduce((earliest, inv) => new Date(inv.purchaseDate) < new Date(earliest.purchaseDate) ? inv : earliest, enriched[0]).purchaseDate
      : null;

    const daysInvesting = firstDate
      ? Math.max(1, Math.floor((new Date() - new Date(firstDate)) / (1000 * 60 * 60 * 24)))
      : 0;

    return {
      investments: enriched,
      totalValue,
      totalCost,
      totalGain,
      totalGainPercent,
      allocationByType,
      bestPerformer,
      daysInvesting,
    };
  }, [investments]);

  return {
    ...computed,
    snapshots,
    addInvestment,
    updateInvestment,
    deleteInvestment,
  };
}
