import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { MountainBackground } from './components/Layout/MountainBackground';
import { Sidebar } from './components/Layout/Sidebar';
import { TopBar } from './components/Layout/TopBar';
import { Dashboard } from './pages/Dashboard';
import { Portfolio } from './pages/Portfolio';
import { Goals } from './pages/Goals';
import { usePortfolio } from './hooks/usePortfolio';
import { useGoals } from './hooks/useGoals';

function App() {
  const portfolio = usePortfolio();
  const goals = useGoals(portfolio.totalValue);

  // Calculate altitude (0-100) based on highest goal
  const summitGoal = goals.goals.length > 0
    ? Math.max(...goals.goals.map(g => g.targetAmount))
    : 500000;
  const altitude = Math.min(100, (portfolio.totalValue / summitGoal) * 100);

  return (
    <div className="min-h-screen relative">
      {/* Mountain Background */}
      <MountainBackground altitude={altitude} />

      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="ml-0 md:ml-64 relative z-10 min-h-screen flex flex-col">
        <TopBar />
        <main className="flex-1 p-4 md:p-8 max-w-7xl mx-auto w-full">
          <Routes>
            <Route 
              path="/" 
              element={<Dashboard portfolio={portfolio} goals={goals.goals} />} 
            />
            <Route 
              path="/portfolio" 
              element={
                <Portfolio 
                  portfolio={portfolio} 
                  onAdd={portfolio.addInvestment}
                  onUpdate={portfolio.updateInvestment}
                  onDelete={portfolio.deleteInvestment}
                />
              } 
            />
            <Route 
              path="/goals" 
              element={
                <Goals 
                  goals={goals.goals}
                  portfolioValue={portfolio.totalValue}
                  onAdd={goals.addGoal}
                  onUpdate={goals.updateGoal}
                  onDelete={goals.deleteGoal}
                />
              } 
            />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default App;
