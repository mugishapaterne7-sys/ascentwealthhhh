import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { PortfolioTable } from '../components/Portfolio/PortfolioTable';
import { AddInvestmentModal } from '../components/Portfolio/AddInvestmentModal';
import { GlassCard } from '../components/UI/GlassCard';
import { AnimatedNumber } from '../components/UI/AnimatedNumber';

const filters = ['All', 'Stock', 'Crypto', 'Real Estate', 'Cash', 'Bond', 'ETF', 'Other'];

export function Portfolio({ portfolio, onAdd, onUpdate, onDelete }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editInvestment, setEditInvestment] = useState(null);
  const [activeFilter, setActiveFilter] = useState('All');

  const { investments, totalValue, totalCost, totalGain } = portfolio;

  const handleEdit = (inv) => {
    setEditInvestment(inv);
    setIsModalOpen(true);
  };

  const handleClose = () => {
    setIsModalOpen(false);
    setEditInvestment(null);
  };

  const handleSubmit = (formData) => {
    if (editInvestment) {
      onUpdate(editInvestment.id, formData);
    } else {
      onAdd(formData);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-serif-display dark:text-white text-slate-900">Your Holdings</h2>
          <p className="text-sm text-slate-400 mt-1">{investments.length} assets in your portfolio</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-ascent-aurora to-ascent-summit text-white text-sm font-medium
            hover:shadow-[0_0_30px_rgba(99,102,241,0.3)] transition-shadow"
        >
          <Plus size={16} />
          Add Investment
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {filters.map((filter) => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              activeFilter === filter
                ? 'bg-ascent-aurora/20 text-ascent-summit border border-ascent-summit/30'
                : 'bg-white/5 text-slate-400 border border-white/5 hover:bg-white/10 hover:text-white'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Portfolio Table */}
      <PortfolioTable
        investments={investments}
        onEdit={handleEdit}
        onDelete={onDelete}
        filter={activeFilter}
      />

      {/* Summary Footer */}
      <GlassCard className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-8">
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wider">Total Value</p>
            <p className="text-xl font-bold dark:text-white text-slate-900">
              <AnimatedNumber value={totalValue} prefix="$" decimals={0} />
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wider">Cost Basis</p>
            <p className="text-xl font-bold text-slate-400">
              <AnimatedNumber value={totalCost} prefix="$" decimals={0} />
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wider">Total Gain/Loss</p>
            <p className={`text-xl font-bold ${totalGain >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              <AnimatedNumber value={totalGain} prefix={totalGain >= 0 ? '+$' : '-$'} decimals={0} />
            </p>
          </div>
        </div>
      </GlassCard>

      {/* Modal */}
      <AddInvestmentModal
        isOpen={isModalOpen}
        onClose={handleClose}
        onSubmit={handleSubmit}
        editInvestment={editInvestment}
      />
    </div>
  );
}
