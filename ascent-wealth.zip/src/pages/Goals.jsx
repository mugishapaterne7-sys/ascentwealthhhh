import React, { useState } from 'react';
import { Plus, Target } from 'lucide-react';
import { GoalCard } from '../components/Goals/GoalCard';
import { AddGoalModal } from '../components/Goals/AddGoalModal';
import { GlassCard } from '../components/UI/GlassCard';
import { AnimatedNumber } from '../components/UI/AnimatedNumber';

export function Goals({ goals, portfolioValue, onAdd, onUpdate, onDelete }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editGoal, setEditGoal] = useState(null);

  const handleEdit = (goal) => {
    setEditGoal(goal);
    setIsModalOpen(true);
  };

  const handleClose = () => {
    setIsModalOpen(false);
    setEditGoal(null);
  };

  const handleSubmit = (formData) => {
    if (editGoal) {
      onUpdate(editGoal.id, formData);
    } else {
      onAdd(formData);
    }
  };

  const achievedCount = goals.filter(g => g.isAchieved).length;
  const totalTarget = goals.reduce((sum, g) => sum + g.targetAmount, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-serif-display dark:text-white text-slate-900">Your Financial Summits</h2>
          <p className="text-sm text-slate-400 mt-1">{goals.length} goals · {achievedCount} achieved</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-ascent-aurora to-ascent-summit text-white text-sm font-medium
            hover:shadow-[0_0_30px_rgba(99,102,241,0.3)] transition-shadow"
        >
          <Plus size={16} />
          Set New Goal
        </button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <GlassCard hover>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-ascent-aurora/10">
              <Target size={18} className="text-ascent-aurora" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Total Goals</p>
              <p className="text-xl font-bold dark:text-white text-slate-900">{goals.length}</p>
            </div>
          </div>
        </GlassCard>
        <GlassCard hover>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-400/10">
              <Target size={18} className="text-emerald-400" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Achieved</p>
              <p className="text-xl font-bold text-emerald-400">{achievedCount}</p>
            </div>
          </div>
        </GlassCard>
        <GlassCard hover>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-ascent-peak/10">
              <Target size={18} className="text-ascent-peak" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Combined Target</p>
              <p className="text-xl font-bold dark:text-white text-slate-900">
                <AnimatedNumber value={totalTarget} prefix="$" decimals={0} />
              </p>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Goals Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {goals.map((goal) => (
          <GoalCard
            key={goal.id}
            goal={goal}
            onEdit={handleEdit}
            onDelete={onDelete}
          />
        ))}
      </div>

      {goals.length === 0 && (
        <GlassCard className="text-center py-16">
          <Target size={48} className="mx-auto text-slate-600 mb-4" />
          <h3 className="text-lg font-medium dark:text-white text-slate-900 mb-2">No goals yet</h3>
          <p className="text-sm text-slate-500 mb-6">Set your first financial summit to start tracking your progress.</p>
          <button
            onClick={() => setIsModalOpen(true)}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-ascent-aurora to-ascent-summit text-white text-sm font-medium"
          >
            Set Your First Goal
          </button>
        </GlassCard>
      )}

      {/* Modal */}
      <AddGoalModal
        isOpen={isModalOpen}
        onClose={handleClose}
        onSubmit={handleSubmit}
        editGoal={editGoal}
      />
    </div>
  );
}
