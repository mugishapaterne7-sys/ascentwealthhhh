import React from 'react';
import { motion } from 'framer-motion';
import { Fuel, TrendingUp, Award, Calendar } from 'lucide-react';
import { NetWorthHero } from '../components/Dashboard/NetWorthHero';
import { AltitudeBar } from '../components/Dashboard/AltitudeBar';
import { AssetAllocation } from '../components/Dashboard/AssetAllocation';
import { PerformanceChart } from '../components/Dashboard/PerformanceChart';
import { QuoteCard } from '../components/Dashboard/QuoteCard';
import { GlassCard } from '../components/UI/GlassCard';
import { AnimatedNumber } from '../components/UI/AnimatedNumber';
import { Badge } from '../components/UI/Badge';

export function Dashboard({ portfolio, goals }) {
  const { totalValue, totalCost, totalGain, totalGainPercent, allocationByType, bestPerformer, daysInvesting, snapshots } = portfolio;

  const stats = [
    {
      label: 'Total Invested',
      value: totalCost,
      prefix: '$',
      icon: Fuel,
      color: 'text-ascent-summit',
      bgColor: 'bg-ascent-summit/10',
    },
    {
      label: 'Total Gains/Losses',
      value: totalGain,
      prefix: '$',
      icon: TrendingUp,
      color: totalGain >= 0 ? 'text-emerald-400' : 'text-red-400',
      bgColor: totalGain >= 0 ? 'bg-emerald-400/10' : 'bg-red-400/10',
      badge: totalGainPercent,
    },
    {
      label: 'Best Performer',
      value: bestPerformer ? bestPerformer.gainPercent : 0,
      prefix: '',
      suffix: '%',
      subtext: bestPerformer ? bestPerformer.name : '—',
      icon: Award,
      color: 'text-ascent-peak',
      bgColor: 'bg-ascent-peak/10',
    },
    {
      label: 'Days Investing',
      value: daysInvesting,
      prefix: '',
      suffix: '',
      icon: Calendar,
      color: 'text-ascent-aurora',
      bgColor: 'bg-ascent-aurora/10',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <NetWorthHero
        totalValue={totalValue}
        totalGain={totalGain}
        totalGainPercent={totalGainPercent}
        snapshots={snapshots}
      />

      {/* Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <GlassCard key={stat.label} delay={index * 0.1} hover>
              <div className="flex items-start justify-between mb-3">
                <div className={`p-2.5 rounded-xl ${stat.bgColor}`}>
                  <Icon size={18} className={stat.color} />
                </div>
                {stat.badge !== undefined && (
                  <Badge value={stat.badge} />
                )}
              </div>
              <p className="text-2xl font-bold dark:text-white text-slate-900">
                {stat.subtext ? (
                  <span className={stat.color}>
                    <AnimatedNumber value={stat.value} prefix={stat.prefix} suffix={stat.suffix} decimals={stat.suffix === '%' ? 1 : 0} />
                  </span>
                ) : (
                  <AnimatedNumber value={stat.value} prefix={stat.prefix} suffix={stat.suffix} decimals={0} />
                )}
              </p>
              {stat.subtext && (
                <p className="text-xs text-slate-500 mt-1 truncate">{stat.subtext}</p>
              )}
              <p className="text-xs text-slate-500 mt-1">{stat.label}</p>
            </GlassCard>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PerformanceChart snapshots={snapshots} />
        <AssetAllocation allocationByType={allocationByType} totalValue={totalValue} />
      </div>

      {/* Altitude Bar */}
      <AltitudeBar totalValue={totalValue} goals={goals} />

      {/* Quote Card */}
      <QuoteCard />
    </div>
  );
}
