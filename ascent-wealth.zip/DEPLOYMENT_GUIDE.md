# 🚀 Ascent Wealth — Free Deployment Guide

This guide covers **three completely free methods** to publish your Ascent Wealth app to the internet, from easiest to most flexible.

---

## 📋 Before You Start

### Step 0: Build Your App Locally

First, make sure everything works on your machine:

```bash
# Navigate to your project folder
cd /mnt/agents/output

# Install dependencies
npm install

# Start the dev server to verify everything works
npm run dev
```

Open `http://localhost:5173` in your browser. You should see the Ascent Wealth dashboard with sample data.

### Step 0.5: Create a Production Build

```bash
npm run build
```

This creates a `dist/` folder containing your compiled, minified, production-ready app. This is what you'll deploy.

> **Important:** The `dist/` folder contains everything needed to run your app — HTML, CSS, JS, and assets. You never deploy the `src/` folder.

---

## 🥇 METHOD 1: Vercel (Recommended — Easiest)

**Why Vercel:** Zero-config deployment, auto-detects Vite, automatic rebuilds on every git push, free custom domains, and the fastest global CDN. Perfect for React apps. citeweb_search:18#3

### Step 1: Create a GitHub Repository

If your code isn't on GitHub yet:

```bash
# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit — Ascent Wealth"

# Create repo on GitHub (via web or gh CLI), then:
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ascent-wealth.git
git push -u origin main
```

### Step 2: Sign Up on Vercel

1. Go to [vercel.com](https://vercel.com)
2. Click **"Sign Up"** → **"Continue with GitHub"**
3. Authorize Vercel to access your repositories

### Step 3: Import Your Project

1. Click **"Add New Project"**
2. Select your `ascent-wealth` repository from the list
3. Click **"Import"**

### Step 4: Configure Build Settings

Vercel auto-detects Vite, but verify these settings:

| Setting | Value |
|---------|-------|
| **Framework Preset** | Vite |
| **Build Command** | `npm run build` |
| **Output Directory** | `dist` |
| **Install Command** | `npm install` |

> **Note:** If Vercel doesn't auto-detect Vite, manually select it from the Framework Preset dropdown. citeweb_search:18#3

### Step 5: Deploy

Click **"Deploy"**. Vercel will:
- Clone your repo
- Run `npm install`
- Run `npm run build`
- Deploy to a global CDN

You'll get a URL like: `https://ascent-wealth-abc123.vercel.app`

### Step 6: Enable SPA Routing (Critical for React Router)

Since Ascent Wealth uses React Router, you need to handle client-side routing. Create a `vercel.json` file in your project root:

```json
{
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

Then commit and push:

```bash
git add vercel.json
git commit -m "Add SPA routing config"
git push
```

Vercel will auto-redeploy. Now `/portfolio` and `/goals` routes work on refresh.

### Step 7: Custom Domain (Optional but Free)

1. In Vercel dashboard → your project → **"Settings"** → **"Domains"**
2. Add your domain (e.g., `ascent-wealth.vercel.app` is already yours, or add a custom one)
3. Follow DNS instructions if using a custom domain
4. **HTTPS is included automatically** — no extra setup

### ✅ Vercel Free Tier Limits

- **Unlimited** sites
- **100 GB** bandwidth/month
- **6,000** build execution minutes/month
- **Serverless Functions** included
- Perfect for personal projects citeweb_search:18#1

---

## 🥈 METHOD 2: Netlify (Great Alternative)

**Why Netlify:** Excellent for Jamstack, form handling, split testing, and has a very generous free tier. citeweb_search:18#7

### Step 1: Push to GitHub

Same as Method 1 — make sure your code is on GitHub.

### Step 2: Sign Up on Netlify

1. Go to [netlify.com](https://netlify.com)
2. Sign up with GitHub

### Step 3: Add New Site

1. Click **"Add new site"** → **"Import an existing project"**
2. Select GitHub as your Git provider
3. Choose your `ascent-wealth` repository

### Step 4: Configure Build Settings

| Setting | Value |
|---------|-------|
| **Build command** | `npm run build` |
| **Publish directory** | `dist` |

> **Critical:** For Vite projects, the publish directory MUST be `dist`, not `build`. citeweb_search:18#0

### Step 5: Add SPA Redirects (Critical)

Create a file `public/_redirects` (in your source, not the dist folder):

```
/* /index.html 200
```

Or create a `netlify.toml` in your project root:

```toml
[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

Commit and push:

```bash
git add public/_redirects netlify.toml
git commit -m "Add Netlify SPA redirects"
git push
```

### Step 6: Deploy

Netlify auto-deploys on every push. Your site will be live at `https://ascent-wealth-abc123.netlify.app`.

### ✅ Netlify Free Tier Limits

- **300** build minutes/month
- **100 GB** bandwidth/month
- **1** concurrent build
- **125,000** serverless function invocations/month citeweb_search:18#0

---

## 🥉 METHOD 3: Cloudflare Pages (Unlimited Bandwidth)

**Why Cloudflare Pages:** Unlimited bandwidth, unlimited requests, 500 builds/month, and the fastest global CDN. Best if you expect traffic. citeweb_search:18#2 citeweb_search:18#5

### Step 1: Push to GitHub

Same as above.

### Step 2: Sign Up on Cloudflare

1. Go to [cloudflare.com](https://cloudflare.com)
2. Create a free account (or log in)

### Step 3: Create Pages Project

1. In the dashboard, go to **"Workers & Pages"**
2. Click **"Create application"**
3. Select the **"Pages"** tab
4. Click **"Connect to Git"**
5. Authorize GitHub and select your repo

### Step 4: Configure Build Settings

| Setting | Value |
|---------|-------|
| **Production branch** | `main` |
| **Build command** | `npm run build` |
| **Build output directory** | `dist` |

### Step 5: Deploy

Click **"Save and Deploy"**. Cloudflare builds and deploys your site.

Your URL will be: `https://ascent-wealth.pages.dev`

### Step 6: Add SPA Routing

Create a `_redirects` file in your `public/` folder:

```
/* /index.html 200
```

Or add to `wrangler.toml` if using Wrangler CLI.

### ✅ Cloudflare Pages Free Tier Limits

- **Unlimited** sites
- **Unlimited** bandwidth
- **Unlimited** requests
- **500** builds/month
- **Best free tier** for high-traffic sites citeweb_search:18#9

---

## 🔧 Quick Reference: Build Settings by Framework

| Framework | Build Command | Output Directory |
|-----------|--------------|------------------|
| Vite (Ascent Wealth) | `npm run build` | `dist` |
| Create React App | `npm run build` | `build` |
| Next.js | `next build` | `.next` |

---

## 🛠️ Troubleshooting Common Issues

### Blank Page After Deploy

**Cause:** Wrong output directory selected.
**Fix:** Check your deploy settings. For Vite, it must be `dist`.

### 404 on Page Refresh (React Router)

**Cause:** Server doesn't know about client-side routes.
**Fix:** Add SPA redirect rules:
- **Vercel:** `vercel.json` with rewrites
- **Netlify:** `_redirects` file or `netlify.toml`
- **Cloudflare:** `_redirects` file citeweb_search:18#0

### Environment Variables Not Working

**Cause:** Wrong prefix.
**Fix:** For Vite, all env vars must start with `VITE_`:
```bash
VITE_API_KEY=your_key_here
```

### Build Fails

**Cause:** Missing dependencies or Node version mismatch.
**Fix:**
1. Check `package.json` has all dependencies
2. Set Node version to 18+ in platform settings
3. Check build logs for specific errors

---

## 📊 Platform Comparison

| Feature | Vercel | Netlify | Cloudflare Pages |
|---------|--------|---------|------------------|
| **Free Sites** | Unlimited | Unlimited | Unlimited |
| **Bandwidth** | 100 GB/mo | 100 GB/mo | **Unlimited** |
| **Build Minutes** | 6,000/mo | 300/mo | 500/mo |
| **Custom Domain** | ✅ Free | ✅ Free | ✅ Free |
| **HTTPS** | ✅ Auto | ✅ Auto | ✅ Auto |
| **Preview Deploys** | ✅ Per branch | ✅ Per branch | ✅ Per branch |
| **Best For** | Next.js/React | Jamstack/Forms | High traffic/CDN |

---

## 🎯 Recommended Path for Ascent Wealth

**For fastest setup:** Use **Vercel** (Method 1). It's literally 3 clicks after pushing to GitHub.

**For unlimited traffic:** Use **Cloudflare Pages** (Method 3). No bandwidth caps ever.

**For form handling:** Use **Netlify** (Method 2) if you later add contact forms.

---

## 🔄 Updating Your Live Site

Once deployed, updates are automatic:

```bash
# Make changes to your code
git add .
git commit -m "Update dashboard styling"
git push
```

Your platform detects the push, rebuilds, and redeploys — usually within 30-60 seconds. No manual steps needed.

---

## 🌐 Custom Domain Setup (All Platforms)

1. Buy a domain (Namecheap, Google Domains, Cloudflare Registrar)
2. In your platform dashboard, go to **Settings → Domains**
3. Add your domain (e.g., `ascent-wealth.com`)
4. Follow the DNS instructions (usually just add a CNAME record)
5. Wait 5-30 minutes for DNS propagation
6. HTTPS certificate is issued automatically

---

## ✅ Deployment Checklist

- [ ] App builds locally with `npm run build`
- [ ] Code is pushed to GitHub
- [ ] Platform account created (Vercel/Netlify/Cloudflare)
- [ ] Repo imported with correct build settings
- [ ] SPA routing configured (redirects/rewrites)
- [ ] Site loads at the provided URL
- [ ] All routes work on direct navigation (`/portfolio`, `/goals`)
- [ ] Dark/light mode toggle works
- [ ] Data persists after refresh (LocalStorage works)
- [ ] (Optional) Custom domain connected

---

**You're now ready to share Ascent Wealth with the world! 🏔️**
