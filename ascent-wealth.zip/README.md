# 🏔️ Ascent Wealth

A premium personal investment tracker with an adventure/mountain-climbing theme. Built with React 18, Vite, Tailwind CSS, Recharts, and Framer Motion.

## Features

- **Dashboard** — Real-time net worth tracking with animated altitude metaphor
- **Portfolio** — Full investment management with add/edit/delete
- **Goals** — Financial summit goals with mountain progress visuals
- **Charts** — Performance area charts and asset allocation donut charts
- **Dark/Light Mode** — Persistent theme toggle
- **LocalStorage** — All data persists across sessions
- **Responsive** — Mobile, tablet, and desktop layouts

## Tech Stack

- React 18 + Vite
- Tailwind CSS
- Recharts (data visualization)
- Framer Motion (animations)
- Lucide React (icons)
- LocalStorage (data persistence)

## Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## File Structure

```
src/
  components/
    Layout/         — Sidebar, TopBar, MountainBackground
    Dashboard/      — NetWorthHero, AltitudeBar, AssetAllocation, PerformanceChart, QuoteCard
    Portfolio/      — PortfolioTable, AddInvestmentModal
    Goals/          — GoalCard, AddGoalModal
    UI/             — GlassCard, AnimatedNumber, Badge
  hooks/
    usePortfolio.js — Portfolio state + LocalStorage
    useGoals.js     — Goals state + LocalStorage
  data/
    quotes.js       — Investor quotes
    sampleData.js   — Sample portfolio for first-time users
  pages/
    Dashboard.jsx
    Portfolio.jsx
    Goals.jsx
  App.jsx
  main.jsx
  index.css
```

## Design System

- **Colors**: Deep space void (#030712), summit blue (#0ea5e9), aurora indigo (#6366f1), peak gold (#f59e0b)
- **Typography**: DM Serif Display (headings), DM Sans (body)
- **Effects**: Glassmorphism cards, aurora glows, mountain SVG background
