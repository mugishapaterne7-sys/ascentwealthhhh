/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'ascent-void': '#030712',
        'ascent-summit': '#0ea5e9',
        'ascent-aurora': '#6366f1',
        'ascent-peak': '#f59e0b',
        'ascent-growth': '#10b981',
        'ascent-loss': '#ef4444',
        'ascent-cloud': 'rgba(255,255,255,0.06)',
        'ascent-glow': 'rgba(99,102,241,0.15)',
      },
      fontFamily: {
        'serif-display': ['"DM Serif Display"', 'serif'],
        'sans': ['"DM Sans"', 'sans-serif'],
      },
      animation: {
        'drift': 'drift 60s linear infinite',
        'pulse-glow': 'pulse-glow 3s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
      },
      keyframes: {
        drift: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-100%)' },
        },
        'pulse-glow': {
          '0%, 100%': { opacity: '0.5' },
          '50%': { opacity: '1' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
    },
  },
  plugins: [],
}
